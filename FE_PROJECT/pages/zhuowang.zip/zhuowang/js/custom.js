window.custom = {
  "banner_txt": "刮奖资格每天上午10:00开抢，名额有限，先到先得哈！",
  "banner_btn": "我的奖品",
  "slogan": "100%中奖，最高免费送2G流量哦"
}

